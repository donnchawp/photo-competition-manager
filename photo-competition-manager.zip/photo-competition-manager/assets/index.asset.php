<?php return array('dependencies' => array(), 'version' => '61e27725b63e23793405');
